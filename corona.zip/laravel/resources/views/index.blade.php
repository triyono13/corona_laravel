@include('template.head')

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    
                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">PasarCoding</a></li>
                                            <li class="breadcrumb-item active">Covid-19 Status</li>
                                        </ol>
                                    <h4 class="page-title"><center><font size="5"> Status Corona Provinsi {{$central->provinsi}}</font></center></h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title -->
                        <div class="row">
                            <div class="col-xl-3 col-lg-6">
                                <div class="card widget-flat">
                                    <div class="card-body p-0">
                                        <div class="p-3 pb-0">

                                            <h5 class="text-muted font-weight-normal mt-0"><b><center> Kasus Positif</center></b></h5><hr>
                                            <h3 class="mt-2"><center>{{$central->kasus_positif}}</center></h3><br>
                                        </div>
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->

                            <div class="col-xl-3 col-lg-6">
                                <div class="card widget-flat">
                                    <div class="card-body p-0">
                                        <div class="p-3 pb-0">

                                            <h5 class="text-muted font-weight-normal mt-0"><b><center> Kasus Sembuh</center></b></h5><hr>
                                            <h3 class="mt-2"><center>{{$central->sembuh}}</center></h3><br>
                                        </div>
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->

                            <div class="col-xl-3 col-lg-6">
                                <div class="card widget-flat">
                                    <div class="card-body p-0">
                                        <div class="p-3 pb-0">

                                            <h5 class="text-muted font-weight-normal mt-0"><b><center> Kasus Meninggal</center></b></h5><hr>
                                            <h3 class="mt-2"><center>{{$central->meninggal}}</center></h3><br>
                                        </div>
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                            <div class="col-xl-3 col-lg-6">
                                <div class="card widget-flat">
                                    <div class="card-body p-0">
                                        <div class="p-3 pb-0">

                                            <h5 class="text-muted font-weight-small mt-0"><b><center> Provinsi</center></b></h5><hr>
                                            <h3 class="mt-2"><center>{{$central->provinsi}}</center></h3>
                                        </div>
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->
                        <span><center>Status di update secara REAL TIME Dari Kementerian Kesehatan & JHU</center></span><br>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    <h3 class="header-title"><center><font size="5">Status Provinsi Lain</font></center> </h3><br>
                                    
                                        <table id="basic-datatable" class="table dt-responsive nowrap">
                                            <thead>
                                                <tr>
                                                    <th scope="col">No.</th>
                                                    <th scope="col">Provinsi</th>
                                                    <th scope="col">Positif</th>
                                                    <th scope="col">Sembuh</th>
                                                    <th scope="col">Meninggal</th>
                                                </tr>
                                            </thead>
                                        
                                        
                                            <tbody>
                                                @foreach ($data as $datas => $hasil)   
                                                <tr>
                                                    <th scope="row">{{$datas +1}}</th>
                                                    <td>{{ $hasil->provinsi }}</td>
                                                    <td>{{ $hasil->kasus_positif }}</td>
                                                    <td>{{ $hasil->sembuh}}</td>
                                                    <td>{{ $hasil->meninggal }}</td>
                                                </tr>
                                                @endforeach 
                                            </tbody>
                                        </table>
                                        
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->
                    </div> <!-- container-fluid -->
                </div> <!-- content -->

                

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                2018 - 2019 &copy; Simulor theme by <a href="">Coderthemes</a>
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-right footer-links d-none d-sm-block">
                                    <a href="#">About Us</a>
                                    <a href="#">Help</a>
                                    <a href="#">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <script src="assets/js/vendor.min.js"></script>

        <!-- datatable js -->
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>

        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Datatables init -->
        <script src="assets/js/pages/datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>
        
    </body>
</html>