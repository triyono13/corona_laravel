<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use App\Corona;

class KawalController extends Controller
{
    
    public function index()
    {
/*        $response = json_decode(file_get_contents('https://api.kawalcorona.com/indonesia/provinsi'));
        
        if (empty($response)){

        }
        else{
            foreach ($response as $sku) {
                $corona = Corona::create([
                    'kode_provinsi' => $sku->attributes->Kode_Provi,
                    'FID' => $sku->attributes->FID,
                    'provinsi' => $sku->attributes->Provinsi,
                    'kasus_positif' => $sku->attributes->Kasus_Posi,
                    'sembuh' => $sku->attributes->Kasus_Semb,
                    'meninggal' => $sku->attributes->Kasus_Meni
                ]);
            }
        }
            */

        $data = Corona::all();
        $id = 18;
        $central = $data->find($id);
        return view('index',compact('data', 'central'));
        
    }
    public function store($response)
    {

    }

}
